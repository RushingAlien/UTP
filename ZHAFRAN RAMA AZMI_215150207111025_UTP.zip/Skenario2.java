public class Skenario2 {
    public static void main(String[] args) {
        
    }
}
